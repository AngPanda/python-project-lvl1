def main():
    print("Welcom to the Brain Games!")
